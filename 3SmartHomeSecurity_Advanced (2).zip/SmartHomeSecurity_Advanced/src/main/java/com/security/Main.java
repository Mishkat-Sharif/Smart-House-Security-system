package com.security;

import org.bytedeco.opencv.opencv_core.Mat;
import org.bytedeco.opencv.opencv_videoio.VideoCapture;

import org.bytedeco.opencv.global.opencv_highgui;
import org.bytedeco.opencv.global.opencv_imgproc;
import org.bytedeco.opencv.global.opencv_imgcodecs;
import org.bytedeco.opencv.global.opencv_core;

public class Main {

    public static void main(String[] args) {

        VideoCapture camera = new VideoCapture(0);

        if (!camera.isOpened()) {
            System.out.println("Camera not found!");
            return;
        }

        Mat frame = new Mat();
        Mat prevGray = new Mat();
        Mat gray = new Mat();
        Mat diff = new Mat();

        int count = 0;

        // 👉 Smart detection variables
        boolean motionDetected = false;
        long lastMotionTime = 0;

        while (true) {
            camera.read(frame);

            if (frame.empty())
                continue;

            // Convert to grayscale
            opencv_imgproc.cvtColor(frame, gray, opencv_imgproc.COLOR_BGR2GRAY);

            if (!prevGray.empty()) {

                // Frame difference
                opencv_core.absdiff(prevGray, gray, diff);

                // Threshold
                opencv_imgproc.threshold(diff, diff, 25, 255, opencv_imgproc.THRESH_BINARY);

                // Motion value
                double motion = opencv_core.sumElems(diff).get(0);

                long currentTime = System.currentTimeMillis();

                // 👉 Motion detected
                if (motion > 1000000) {
                    lastMotionTime = currentTime;

                    if (!motionDetected) {
                        System.out.println("Human Entered!");

                        String filename = "capture_" + count++ + ".png";
                        opencv_imgcodecs.imwrite(filename, frame);

                        motionDetected = true; // lock
                    }
                }

                // 👉 No motion for 3 sec → reset
                if (motionDetected && (currentTime - lastMotionTime > 3000)) {
                    System.out.println("Human Left!");
                    motionDetected = false; // unlock
                }
            }

            // Update previous frame
            gray.copyTo(prevGray);

            // Show camera
            opencv_highgui.imshow("Smart Security Camera", frame);

            // ESC to exit
            if (opencv_highgui.waitKey(30) == 27)
                break;
        }

        camera.release();
        opencv_highgui.destroyAllWindows();
    }
}